#!/bin/bash

main() {
	read -r pid1 < pid.file
	echo $$ > pid.file
	sleep 1
}

write() {
	echo $line > line.file
	kill -USR1 $pid1
}

read_files() {
	read -r line < line.file
	sed -n $line$p < lyrics.txt | awk 'BEGIN { FS="$" } { print $2 }'
}

trap "read_files" TERM USR2

line=1
p="p"

echo $$ > pid.file

while [ 1 -gt 0 ]
do
	main
	if [[ $pid1 == $$ ]];then
		echo ...
	else
		singer=$(sed -n $line$p < lyrics.txt | awk 'BEGIN { FS="$" }{ print $1 }')
		if [[ $singer == 1 ]];then
			write
			echo ...
		fi
		line=$(($line + 1))
	fi
done
