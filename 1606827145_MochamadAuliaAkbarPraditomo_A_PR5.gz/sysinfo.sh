#!/bin/bash

function OSInfo() {
echo ------------------------------------------------------------------
echo       System Status
echo ------------------------------------------------------------------
echo Username: $(uname)
echo OS: $(cat /proc/version | awk '{print $1,$3}')
echo Uptime: $(uptime | awk '{sub(/^[^:]*:[^:]*:[^u]*up /,"");sub(/ users.*/,""); print}')
echo IP: $( ip addr | grep "inet " | tail -n 1 | awk '{print $2}')
echo Hostname: $(hostname)
read -p "Press [ENTER] key to continue..."
mainMenu
}

function hardwareList() {
echo -------------------------------------------
echo       Hardware List
echo -------------------------------------------
echo Machine Hardware: $(uname -m)
lshw -short
read -p "Press [ENTER] key to continue..."
mainMenu
}

function memoryStat() {
echo -------------------------------------------
echo        MEMORY
echo -------------------------------------------
echo "****************"
echo      Memory
echo "****************"
echo "Size : $(free -m | grep 'Mem' | awk '{print $2}') MB"
echo "Free : $(free -m | grep 'Mem' | awk '{print $4}') MB"
echo "***************************"
echo      Memory Statistics
echo "***************************"
vmstat
echo "**********************************"
echo     Top 10 cpu eating process
echo "**********************************"
ps aux --sort=-%cpu | head -n 11
read -p "Press [ENTER] key to continue..."
mainMenu
}

function hardwareDetailMenu() {
echo =========================
echo      Hardware Detail
echo =========================
echo 1. CPU
echo 2. Block Devices
echo 3. Back
askInput 3
processHardwareDetail $input
}

function processHardwareDetail() {
if [ -z $1 ]; then
	echo please specify input!
	mintaInput 3
	processHardwareDetail $input
elif [ $1 == 1 ]; then
	echo -------------------------------------------
	echo      CPU
	echo -------------------------------------------
	echo Model Name :$(cat /proc/cpuinfo | grep 'model name' | awk 'BEGIN{FS=":"}{print $2}')
	echo Frequency :$(cat /proc/cpuinfo | grep 'cpu M' | awk 'BEGIN{FS=":"}{print $2}')
	echo Cache :$(cat /proc/cpuinfo | grep 'cache size' | awk 'BEGIN{FS=":"}{print $2}')
	read -p "Press [ENTER] key to continue..."
	hardwareDetailMenu
elif [ $1 == 2 ]; then
	echo ------------------------------------------------
	echo      blk
	echo ------------------------------------------------
	lsblk
	read -p "Press [ENTER] key to continue..."
	hardwareDetailMenu
elif [ $1 == 3 ]; then
	mainMenu
else
	echo wrong command!
	mintaInput 3
	processHardwareDetail $input
fi
}

function askInput() {
echo -n "choose 1-$1: "
read input
}

function mainMenuInput() {
if [ -z $1 ]; then
	echo please specify input!
	askInput 5
	mainMenuInput $input
elif [ $1 == 1 ]; then
	OSInfo
elif [ $1 == 2 ]; then
	hardwareList
elif [ $1 == 3 ]; then
	memoryStat
elif [ $1 == 4 ]; then
	hardwareDetailMenu
elif [ $1 == 5 ]; then
	echo Bye bye....
	exit 1
else 
	echo wrong command!
	askInput 5
	mainMenuInput $input
fi
}

function mainMenu() {
echo ====================
echo      Main Menu
echo ====================
echo 1. Operating System Info
echo 2. Hardware List
echo 3. Free and Used Memory
echo 4. Hardware Detail
echo 5. exit
askInput 5
mainMenuInput $input
}

mainMenu
