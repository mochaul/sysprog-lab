#!/bin/bash

main() {
	echo $$ > pid.file
	sleep 1
	read -r pid2 < pid.file
}

write() {
	echo $line > line.file
	kill -USR2 $pid2
}

read_files() {
	read -r line < line.file
	sed -n $line$p < lyrics.txt | awk 'BEGIN { FS="$" }{ print $2 }'
}

trap "read_files" TERM USR1

line=1
p="p"

while [ 1 -gt 0 ]
do
	main
	if [[ $pid2 == $$ ]];then
		echo ....
	else
		singer=$(sed -n $line$p < lyrics.txt | awk 'BEGIN { FS="$" }{ print $1 }')
		if [[ $singer == 2 ]];then
			echo ...
			write
		fi
		line=$(($line + 1))
	fi	
done
