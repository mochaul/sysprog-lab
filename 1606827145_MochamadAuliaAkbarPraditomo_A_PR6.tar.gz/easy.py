# importing modules
import RPi.GPIO as GPIO
import time

# setup GPIO pins
GPIO.setmode(GPIO.BOARD)

# green light pins setup
GPIO.setup(8, GPIO.OUT)
GPIO.setup(10, GPIO.IN)
GPIO.setup(12, GPIO.OUT)
GPIO.setup(16, GPIO.IN)
GPIO.setup(18, GPIO.OUT)
GPIO.setup(22, GPIO.IN)

# red light pins setup
GPIO.setup(3, GPIO.OUT)
GPIO.setup(5, GPIO.IN)
GPIO.setup(7, GPIO.OUT)
GPIO.setup(11, GPIO.IN)
GPIO.setup(13, GPIO.OUT)
GPIO.setup(15, GPIO.IN)

# function for checking if a number is a prime number
def isPrime(num):
    if num < 2:
        return False
    if num == 2:
        return True
    else:
        for div in range(2,num):
            if num % div == 0:
                return False
        return True

# function for checking if a number is even
def isEven(num):
  if num%2==0:
    return True
  return False

# main method
def main():
  # ask input
  num = int(input("Enter any number: "))
  if isPrime(num): # check if the number is prime
    GPIO.output(3, GPIO.HIGH)
    GPIO.output(7, GPIO.HIGH)
    GPIO.output(13, GPIO.HIGH)
    time.sleep(1)
    GPIO.output(3, GPIO.LOW)
    GPIO.output(7, GPIO.LOW)
    GPIO.output(13, GPIO.LOW)
    time.sleep(1)
    GPIO.output(8, GPIO.HIGH)
    GPIO.output(12, GPIO.HIGH)
    GPIO.output(18, GPIO.HIGH)
    time.sleep(1)
    GPIO.output(8, GPIO.LOW)
    GPIO.output(12, GPIO.LOW)
    GPIO.output(18, GPIO.LOW)
    time.sleep(1)
    GPIO.output(3, GPIO.HIGH)
    GPIO.output(7, GPIO.HIGH)
    GPIO.output(13, GPIO.HIGH)
    time.sleep(1)
    GPIO.output(3, GPIO.LOW)
    GPIO.output(7, GPIO.LOW)
    GPIO.output(13, GPIO.LOW)
    time.sleep(1)
    GPIO.output(8, GPIO.HIGH)
    GPIO.output(12, GPIO.HIGH)
    GPIO.output(18, GPIO.HIGH)
    time.sleep(1)
    GPIO.output(8, GPIO.LOW)
    GPIO.output(12, GPIO.LOW)
    GPIO.output(18, GPIO.LOW)
    time.sleep(1)
  elif isEven(num): # check if the number is even
    GPIO.output(3, GPIO.HIGH)
    GPIO.output(7, GPIO.LOW)
    GPIO.output(13, GPIO.LOW)
    time.sleep(1)
    GPIO.output(3, GPIO.LOW)
    GPIO.output(7, GPIO.HIGH)
    GPIO.output(13, GPIO.LOW)
    time.sleep(1)
    GPIO.output(3, GPIO.LOW)
    GPIO.output(7, GPIO.LOW)
    GPIO.output(13, GPIO.HIGH)
    time.sleep(1)
    GPIO.output(13, GPIO.LOW)
  else: # else if the number is odd
    GPIO.output(8, GPIO.HIGH)
    GPIO.output(12, GPIO.LOW)
    GPIO.output(18, GPIO.LOW)
    time.sleep(1)
    GPIO.output(8, GPIO.LOW)
    GPIO.output(12, GPIO.HIGH)
    GPIO.output(18, GPIO.LOW)
    time.sleep(1)
    GPIO.output(8, GPIO.LOW)
    GPIO.output(12, GPIO.LOW)
    GPIO.output(18, GPIO.HIGH)
    time.sleep(1)
    GPIO.output(18, GPIO.LOW)
    time.sleep(1)
       
main()
