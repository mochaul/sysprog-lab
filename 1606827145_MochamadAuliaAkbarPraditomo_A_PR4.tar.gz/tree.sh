currDir=0
counter=0
cd .
dirr=$(pwd)
echo Initial Directory = $dirr
function treeDir()
{
subIndent="|"
for dir in */;
	do
		subdir=`find $dir -maxdepth 1 -type d | wc -l`;
		currDir=+~~~;
		if [ $subdir -ne 1 ]; then
			subsCount="$(printf "%${counter}s")"
			echo "${subsCount// /$subIndent} $currDir$dir"
			counter=$((counter+1))		
			cd $dir;
			treeDir;
			counter=$((counter-1))
			cd ..;
		elif [ $counter -ne 0 ]; then
			subsCount="$(printf "%${counter}s")"
			echo "${subsCount// /$subIndent} $currDir$dir"
		else
			echo "$currDir$dir"
		
		fi		
        done
}
treeDir
