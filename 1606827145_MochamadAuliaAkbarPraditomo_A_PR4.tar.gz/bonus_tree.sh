currDir=0
counter=0
jumlah=0
cd .
dirr=$(pwd)
echo Initial Directory = $dirr
function treeDir()
{
subIndent="|"
for dir in */;
	do
		subdir=`find $dir -maxdepth 1 -type d | wc -l`;
		currDir=+~~~;
		if [ $subdir -ne 1 ]; then
			subsCount="$(printf "%${counter}s")"
			echo "${subsCount// /$subIndent} $currDir$dir"
			counter=$((counter+1))		
			cd $dir;
			treeDir;
			counter=$((counter-1))
			cd ..;
			jumlah=$((jumlah+1))
		elif [ $counter -ne 0 ]; then
			subsCount="$(printf "%${counter}s")"
			echo "${subsCount// /$subIndent} $currDir$dir"
			jumlah=$((jumlah+1))
		else
			echo "$currDir$dir"
			jumlah=$((jumlah+1))
		
		fi		
        done
}
treeDir
echo Total directories =  $jumlah
